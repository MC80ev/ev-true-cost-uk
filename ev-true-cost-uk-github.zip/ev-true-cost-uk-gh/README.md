# EV True Cost UK

Free UK calculator for EV salary sacrifice net cost (tax/NI + 4% BiK) plus home charging vs petrol.

## Live

GitHub Pages: *(enable in repo Settings → Pages → Deploy from branch `main` / root)*

## Local

Open `index.html` in a browser.

## Notes

- Estimates only — not tax advice

- Rates targeted at UK 2026/27
